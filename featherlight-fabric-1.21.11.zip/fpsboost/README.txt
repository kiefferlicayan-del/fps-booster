Featherlight - Fabric mod for Minecraft Java 1.21.11 (client only)
Press RIGHT SHIFT in-game to open/close the settings screen.

BUILD WITHOUT A PC:
1. Make a free GitHub repo, upload ALL files in this folder (keep the .github folder).
2. Open the Actions tab -> "build" -> wait for green check.
3. Download the artifact "featherlight-jar" (zip) and take the jar WITHOUT "-sources".

BUILD ON PC: install Java 21 + Gradle 9.2.1, run: gradle build  (jar in build/libs)

INSTALL: needs Fabric Loader + Fabric API for 1.21.11. Put featherlight jar and fabric-api jar in the mods folder.
Config file: config/featherlight.json
