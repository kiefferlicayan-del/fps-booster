package com.fpsboost;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

public class FpsBoostScreen extends Screen {
	private static final int W = 200;
	private static final int H = 20;
	private static final int GAP = 4;
	private static final int[] TARGETS = {30, 45, 60, 90, 120, 144};

	private final Screen parent;

	public FpsBoostScreen() {
		this(null);
	}

	public FpsBoostScreen(Screen parent) {
		super(Text.literal("Featherlight"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		Config c = FpsBoostClient.config;
		int x = this.width / 2 - W / 2;
		int y = this.height / 2 - 96;

		// On / off
		this.addDrawableChild(ButtonWidget.builder(label("Auto FPS Boost", c.enabled), b -> {
			c.enabled = !c.enabled;
			c.save();
			b.setMessage(label("Auto FPS Boost", c.enabled));
		}).dimensions(x, y, W, H).build());
		y += H + GAP;

		// Target FPS (cycles)
		this.addDrawableChild(ButtonWidget.builder(Text.literal("Target FPS: " + c.targetFps), b -> {
			int next = TARGETS[0];
			for (int t : TARGETS) {
				if (t > c.targetFps) {
					next = t;
					break;
				}
			}
			c.targetFps = next;
			c.save();
			b.setMessage(Text.literal("Target FPS: " + c.targetFps));
		}).dimensions(x, y, W, H).build());
		y += H + GAP;

		// Presets row: 4 buttons
		int pw = (W - 3 * GAP) / 4;
		for (int i = 0; i < FpsBoostClient.PRESET_NAMES.length; i++) {
			final int idx = i;
			this.addDrawableChild(ButtonWidget.builder(Text.literal(FpsBoostClient.PRESET_NAMES[i]), b -> {
				FpsBoostClient.applyPreset(this.client, idx);
				this.clearAndInit();
			}).dimensions(x + i * (pw + GAP), y, pw, H).build());
		}
		y += H + GAP;

		// Render distance steppers
		y = addStepper(x, y, "Min Render Dist", () -> c.minViewDistance, v -> {
			c.minViewDistance = v;
			c.clamp();
		});
		y = addStepper(x, y, "Max Render Dist", () -> c.maxViewDistance, v -> {
			c.maxViewDistance = v;
			c.clamp();
		});

		// Toggles, two per row
		int hw = (W - GAP) / 2;
		addToggle(x, y, hw, "Sim Dist", () -> c.adjustSimulation, v -> c.adjustSimulation = v);
		addToggle(x + hw + GAP, y, hw, "Particles", () -> c.adjustParticles, v -> c.adjustParticles = v);
		y += H + GAP;
		addToggle(x, y, hw, "Entities", () -> c.adjustEntityDistance, v -> c.adjustEntityDistance = v);
		addToggle(x + hw + GAP, y, hw, "Graphics", () -> c.adjustGraphics, v -> c.adjustGraphics = v);
		y += H + GAP;
		addToggle(x, y, hw, "FPS Counter", () -> c.showFps, v -> c.showFps = v);
		this.addDrawableChild(ButtonWidget.builder(Text.literal("Reset to Mine"), b -> {
			FpsBoostClient.resetToOriginal(this.client);
			this.clearAndInit();
		}).dimensions(x + hw + GAP, y, hw, H).build());
		y += H + GAP + 6;

		// Done
		this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> this.close())
				.dimensions(x, y, W, H).build());
	}

	private void addToggle(int x, int y, int w, String name, BooleanSupplier get, java.util.function.Consumer<Boolean> set) {
		this.addDrawableChild(ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
			set.accept(!get.getAsBoolean());
			FpsBoostClient.config.save();
			b.setMessage(label(name, get.getAsBoolean()));
		}).dimensions(x, y, w, H).build());
	}

	private int addStepper(int x, int y, String name, IntSupplier get, IntConsumer set) {
		this.addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> {
			set.accept(get.getAsInt() - 1);
			FpsBoostClient.config.save();
			this.clearAndInit();
		}).dimensions(x, y, 20, H).build());

		ButtonWidget mid = ButtonWidget.builder(Text.literal(name + ": " + get.getAsInt()), b -> {
		}).dimensions(x + 22, y, W - 44, H).build();
		mid.active = false;
		this.addDrawableChild(mid);

		this.addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> {
			set.accept(get.getAsInt() + 1);
			FpsBoostClient.config.save();
			this.clearAndInit();
		}).dimensions(x + W - 20, y, 20, H).build());

		return y + H + GAP;
	}

	private static Text label(String name, boolean on) {
		return Text.literal(name + ": " + (on ? "ON" : "OFF"));
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);

		String title = "Featherlight";
		int tw = this.textRenderer.getWidth(title);
		context.drawTextWithShadow(this.textRenderer, title, this.width / 2 - tw / 2, this.height / 2 - 122, 0xFFFFFFFF);

		int fps = this.client != null ? this.client.getCurrentFps() : 0;
		String status = "FPS: " + fps + "   |   Saving level: " + FpsBoostClient.level;
		int sw = this.textRenderer.getWidth(status);
		context.drawTextWithShadow(this.textRenderer, status, this.width / 2 - sw / 2, this.height / 2 - 110, 0xFFAAAAAA);
	}

	@Override
	public void close() {
		if (this.client != null) {
			this.client.setScreen(this.parent);
		}
	}

	@Override
	public boolean shouldPause() {
		return false;
	}
}
