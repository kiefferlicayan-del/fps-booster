package com.fpsboost;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Config {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("featherlight.json");

	public boolean enabled = true;
	public int targetFps = 60;
	public int minViewDistance = 4;
	public int maxViewDistance = 12;
	public boolean adjustSimulation = true;
	public boolean adjustParticles = true;
	public boolean adjustEntityDistance = true;
	public boolean adjustGraphics = true;
	public boolean showFps = true;

	public static Config load() {
		try {
			if (Files.exists(FILE)) {
				Config c = GSON.fromJson(Files.readString(FILE), Config.class);
				if (c != null) {
					c.clamp();
					return c;
				}
			}
		} catch (Exception ignored) {
		}
		Config c = new Config();
		c.save();
		return c;
	}

	public void clamp() {
		targetFps = Math.max(20, Math.min(240, targetFps));
		minViewDistance = Math.max(2, Math.min(32, minViewDistance));
		maxViewDistance = Math.max(2, Math.min(32, maxViewDistance));
		if (minViewDistance > maxViewDistance) {
			minViewDistance = maxViewDistance;
		}
	}

	public void save() {
		try {
			Files.writeString(FILE, GSON.toJson(this));
		} catch (IOException ignored) {
		}
	}
}
