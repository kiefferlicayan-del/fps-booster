package com.fpsboost;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class FpsBoostClient implements ClientModInitializer {
	public static Config config;
	private static FpsBoostClient instance;

	public static final String[] PRESET_NAMES = {"Quality", "Balanced", "Perf", "Potato"};
	private static final int[] PRESET_MIN = {8, 6, 4, 2};
	private static final int[] PRESET_MAX = {16, 12, 8, 4};
	private static final double[] PRESET_ENTITY = {1.0, 0.75, 0.5, 0.5};
	private static final ParticlesMode[] PRESET_PARTICLES = {
			ParticlesMode.ALL, ParticlesMode.DECREASED, ParticlesMode.DECREASED, ParticlesMode.MINIMAL
	};

	private static boolean keyWasDown = false;

	// Auto-tuning state
	private int tickCounter = 0;
	private int lowStreak = 0;
	private int highStreak = 0;
	private int cooldown = 0;

	// What the player had before we touched anything, so we can restore it
	private boolean haveSaved = false;
	private int savedView, savedSim;
	private ParticlesMode savedParticles;
	private double savedEntityDist;
	private GraphicsMode savedGraphics;
	private boolean savedShadows;
	private int savedBlend;

	/** Level 0 = untouched. Higher = more aggressive saving. */
	public static int level = 0;

	@Override
	public void onInitializeClient() {
		instance = this;
		config = Config.load();
		ClientTickEvents.END_CLIENT_TICK.register(this::onTick);

		// FPS counter (top-right corner)
		HudElementRegistry.addLast(Identifier.of("featherlight", "fps_counter"), (context, tickCounter) -> {
			MinecraftClient mc = MinecraftClient.getInstance();
			if (!config.showFps || mc.options.hudHidden || mc.world == null) {
				return;
			}
			String s = mc.getCurrentFps() + " FPS" + (level > 0 ? " (boost " + level + ")" : "");
			int w = mc.textRenderer.getWidth(s);
			context.drawTextWithShadow(mc.textRenderer, s, context.getScaledWindowWidth() - w - 4, 4, 0xFFFFFF55);
		});

		// Button on the pause menu so no keyboard is needed
		ScreenEvents.AFTER_INIT.register((client, screen, sw, sh) -> {
			if (screen instanceof GameMenuScreen) {
				Screens.getButtons(screen).add(
						ButtonWidget.builder(Text.literal("Featherlight"), b -> client.setScreen(new FpsBoostScreen(screen)))
								.dimensions(6, sh - 26, 90, 20).build());
			}
		});
	}

	/** Applies a preset right away (0 Quality, 1 Balanced, 2 Perf, 3 Potato). */
	public static void applyPreset(MinecraftClient client, int idx) {
		if (instance != null) {
			instance.restore(client);
		}
		config.enabled = true;
		config.minViewDistance = PRESET_MIN[idx];
		config.maxViewDistance = PRESET_MAX[idx];
		config.adjustSimulation = true;
		config.adjustParticles = true;
		config.adjustEntityDistance = true;
		config.adjustGraphics = true;
		config.clamp();
		config.save();

		GameOptions o = client.options;
		o.getViewDistance().setValue(PRESET_MAX[idx]);
		o.getSimulationDistance().setValue(PRESET_MAX[idx]);
		o.getParticles().setValue(PRESET_PARTICLES[idx]);
		o.getEntityDistanceScaling().setValue(PRESET_ENTITY[idx]);
	}

	private void onTick(MinecraftClient client) {
		handleKey(client);
		autoTune(client);
	}

	// ---------------------------------------------------------------- key

	private void handleKey(MinecraftClient client) {
		if (client.getWindow() == null) {
			return;
		}
		long handle = client.getWindow().getHandle();
		boolean down = GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;

		if (down && !keyWasDown) {
			if (client.currentScreen instanceof FpsBoostScreen) {
				client.setScreen(null);
			} else if (client.currentScreen == null) {
				client.setScreen(new FpsBoostScreen());
			}
		}
		keyWasDown = down;
	}

	// ---------------------------------------------------------- auto-tune

	private void autoTune(MinecraftClient client) {
		if (client.world == null || client.player == null) {
			return;
		}
		if (!config.enabled) {
			restore(client);
			return;
		}

		if (cooldown > 0) {
			cooldown--;
		}
		// sample once per second
		if (++tickCounter < 20) {
			return;
		}
		tickCounter = 0;

		int fps = client.getCurrentFps();
		if (fps <= 0) {
			return;
		}

		if (fps < config.targetFps * 0.9) {
			lowStreak++;
			highStreak = 0;
		} else if (fps > config.targetFps * 1.4) {
			highStreak++;
			lowStreak = 0;
		} else {
			lowStreak = 0;
			highStreak = 0;
		}

		if (cooldown > 0) {
			return;
		}

		if (lowStreak >= 2) {
			lowStreak = 0;
			save(client);
			changeLevel(client, +1);
			cooldown = 8; // seconds before next change (chunks need to reload)
		} else if (highStreak >= 6 && level > 0) {
			highStreak = 0;
			changeLevel(client, -1);
			cooldown = 8;
		}
	}

	private void save(MinecraftClient client) {
		if (haveSaved) {
			return;
		}
		GameOptions o = client.options;
		savedView = o.getViewDistance().getValue();
		savedSim = o.getSimulationDistance().getValue();
		savedParticles = o.getParticles().getValue();
		savedEntityDist = o.getEntityDistanceScaling().getValue();
		savedGraphics = o.getGraphicsMode().getValue();
		savedShadows = o.getEntityShadows().getValue();
		savedBlend = o.getBiomeBlendRadius().getValue();
		haveSaved = true;
	}

	/** Steps the settings down (+1) or back up (-1). Never goes above what the player had. */
	private void changeLevel(MinecraftClient client, int delta) {
		GameOptions o = client.options;
		int top = Math.min(config.maxViewDistance, haveSaved ? Math.max(savedView, config.minViewDistance) : config.maxViewDistance);

		// view distance: 1 chunk per level, between min and top
		int view = o.getViewDistance().getValue() - delta;
		view = Math.max(config.minViewDistance, Math.min(top, view));
		if (view != o.getViewDistance().getValue()) {
			o.getViewDistance().setValue(view);
		}

		boolean atFloor = view <= config.minViewDistance;
		boolean atTop = view >= top;

		if (delta > 0 && !atFloor) {
			level++;
		} else if (delta > 0) {
			// view distance already at floor: dig into the other options
			level++;
			applyExtras(client, true);
		} else {
			if (level > 0) {
				level--;
			}
			if (atTop || level == 0) {
				applyExtras(client, false);
			}
		}

		if (level == 0 && delta < 0) {
			// fully recovered
			restore(client);
		}
	}

	private void applyExtras(MinecraftClient client, boolean saving) {
		GameOptions o = client.options;
		if (!haveSaved) {
			return;
		}
		if (saving) {
			if (config.adjustSimulation) {
				int sim = Math.max(config.minViewDistance, Math.min(savedSim, o.getViewDistance().getValue()));
				if (o.getSimulationDistance().getValue() != sim) {
					o.getSimulationDistance().setValue(sim);
				}
			}
			if (config.adjustParticles) {
				o.getParticles().setValue(level >= 4 ? ParticlesMode.MINIMAL : ParticlesMode.DECREASED);
			}
			if (config.adjustEntityDistance) {
				o.getEntityDistanceScaling().setValue(Math.min(savedEntityDist, 0.6));
			}
			if (config.adjustGraphics) {
				if (savedGraphics != GraphicsMode.FAST) {
					o.getGraphicsMode().setValue(GraphicsMode.FAST);
				}
				o.getEntityShadows().setValue(false);
				o.getBiomeBlendRadius().setValue(Math.min(savedBlend, 1));
			}
		} else {
			if (config.adjustSimulation) {
				o.getSimulationDistance().setValue(savedSim);
			}
			if (config.adjustParticles) {
				o.getParticles().setValue(savedParticles);
			}
			if (config.adjustEntityDistance) {
				o.getEntityDistanceScaling().setValue(savedEntityDist);
			}
			if (config.adjustGraphics) {
				o.getGraphicsMode().setValue(savedGraphics);
				o.getEntityShadows().setValue(savedShadows);
				o.getBiomeBlendRadius().setValue(savedBlend);
			}
		}
	}

	/** Puts back everything the player had and pauses Featherlight. */
	public static void resetToOriginal(MinecraftClient client) {
		if (instance != null) {
			instance.restore(client);
		}
		config.enabled = false;
		config.save();
	}

	/** Puts the player's own settings back. */
	public void restore(MinecraftClient client) {
		if (!haveSaved) {
			level = 0;
			return;
		}
		GameOptions o = client.options;
		o.getViewDistance().setValue(savedView);
		o.getSimulationDistance().setValue(savedSim);
		o.getParticles().setValue(savedParticles);
		o.getEntityDistanceScaling().setValue(savedEntityDist);
		o.getGraphicsMode().setValue(savedGraphics);
		o.getEntityShadows().setValue(savedShadows);
		o.getBiomeBlendRadius().setValue(savedBlend);
		haveSaved = false;
		level = 0;
		lowStreak = 0;
		highStreak = 0;
	}
}
